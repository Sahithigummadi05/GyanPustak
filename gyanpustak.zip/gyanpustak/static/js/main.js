// Auto-hide flash messages after 4 seconds
document.addEventListener('DOMContentLoaded', function () {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 500);
        }, 4000);
    });
});

// Tab switching for admin dashboard
function showTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(function (el) {
        el.style.display = 'none';
    });
    document.querySelectorAll('.tab-btn').forEach(function (btn) {
        btn.classList.remove('active');
    });
    const target = document.getElementById(tabId);
    if (target) target.style.display = '';
    event.target.classList.add('active');
}

// Star rating fix — clicking a lower star should highlight correctly
document.addEventListener('DOMContentLoaded', function () {
    const starLabels = document.querySelectorAll('.star-input label');
    starLabels.forEach(function (label) {
        label.addEventListener('mouseover', function () {
            const stars = label.parentElement.querySelectorAll('label');
            let found = false;
            stars.forEach(function (s) {
                if (s === label) found = true;
                s.style.color = found ? '' : '#F59E0B';
            });
        });
    });
});
